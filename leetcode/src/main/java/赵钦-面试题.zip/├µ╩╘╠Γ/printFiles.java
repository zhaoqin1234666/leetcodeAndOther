package 面试题;

import java.io.File;
import java.io.FileWriter;
import java.util.*;

/**
 * 遍历打印文件夹
 * @ClassName printFiles
 * @Author zhaoqin
 * @Date 2020/3/16
 */
public class printFiles {
    private static List<String> fileList = new ArrayList<>();
    private static List<String> dirList = new ArrayList<>();


    private Map<String, Long> map = new HashMap<String, Long>();
    private Set<String> fileTypeSet = new LinkedHashSet<>();//有序set

    public void main(String[] args) {
        File targetDir = new File("C:\\Users\\haili\\Desktop\\leetcode");

        //第二题 第二问
        listFiles(targetDir.getAbsolutePath());

        //文件夹数量
        System.out.println(dirList.size() + "个");
        //文件数量
        System.out.println(fileList.size() +"个");

        //第二题 第一问 按照文件类型和文件大小排序

        //文件类型 去重(LinkedHashSet 是有序的set)
        for (String filename : fileList){
            String[] fileTypes = filename.split("\\.");
            fileTypeSet.add(fileTypes[1]);
        }

        for(String fileType : fileTypeSet){
            for (String filename : fileList){
                if(!filename.split("\\.")[1].equals(filename))
                    continue;
                System.out.println("文件类型 ="+ fileType + "文件名字="+filename);

            }
        }

    }

    /**
     * 第二题 第二问
     * 遍历打印所有文件
     */
    public static void listFiles(String path){
        //目标文件夹
        File targetDir = new File(path);
        if(!targetDir.exists())
            System.out.println("该文件夹不存在!");

        //递归
        for(File file : targetDir.listFiles()){
            if(file.isDirectory()){
                dirList.add(file.getName());
                System.out.println("文件夹：" + file.getName() + " " + file.length());
                listFiles(file.getAbsolutePath());
            }
            else{
                fileList.add(file.getName());
                System.out.println("文件:" + file.getName() + " " + file.length());
            }

        }
    }



}
