package 面试题;

/**
 * @ClassName B
 * @Author zhaoqin
 * @Date 2020/3/16
 */
public class B {

    public void c(Object d){
        System.out.println("方法c正在执行!,参数为" + d);
    }
}
